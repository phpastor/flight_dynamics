
%-----------------------------------------
%
%  R�-affectation aux anciennes variables
%
%-----------------------------------------

  iTempRoot = SimuOuRoot ;

  itrac     = DonTrace   ;

  x0beta = beta0 ;
  x0r    = r0    ;
  x0p    = p0    ;
  x0phi  = phi0  ;

  dlE    = dl    ;
  dnE    = dn    ;


  % Matrice des gains de commandes

  if exist('KPlaceMod') == 1
    KBetat = KPlaceMod ;
  else
    KBetat  = [kdlBeta kdlr kdlp kdlPhi  ;  ...
               kdnBeta kdnr kdnp kdnPhi ] ; 
  end

  % Matrices bool�enne pour le trac� du lieu des racines

  LRKBetat = TabLieuMod ;

  % Cas de vol

   AltVol = Altitude  ;
   VitVol = Vitesse   ;
   msVol  = MargeStat ;

  % Coefficients multiplicatifs

   kCoef   = [kSD kCnb kClb] ;

%-----------------------------
%
% Initialisation 
%
%-----------------------------

%   Lecture des constantes

   CPhysique ;
   CUnite    ;

%  Atmosph�re

   CAtmStand ;

   atmosphere = AtmStand(AltVol,Catm) ; 

   pression = atmosphere.Pression    ;
   rho      = atmosphere.Densite     ;
   Temp     = atmosphere.Temperature ;
   ason     = atmosphere.VitSon      ;
%  mu       = atmosphere.Atmo.VisDyn ; 
%  nu       = atmosphere.Atmo.VisCin ;

%---------------------------------------
%
%  D�finition des vecteurs pour
%  la simulation temporelle
%
%----------------------------------------

  % �tat initial

  x0 = deg2rad* [x0beta ; x0r; x0p; x0phi ] ; 


  % Vecteur temporel

  dt     = 0.2    ; % P�riode �chantillonnage (sec.)

  NpSimu = round(TempsSimu/dt) + 1 ;  % Nombre de points
  NpvS   = NpSimu - 1 ;
  t      = (0:NpvS)' * dt ;

  % Vecteurs des entr�es

  u = ones(NpSimu,1)*[dlE*deg2rad dnE*deg2rad] ;

%-----------------------------------
%
%  Ex�cution de la simulation 
%
%-----------------------------------


   SimuTempMod ; 



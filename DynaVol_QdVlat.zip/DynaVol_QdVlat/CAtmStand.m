
%*****************************************************************************

% CONSTANTES DE L'ATMOSPHERE STANDARD
%  ET DE L'ACCELERATION GRAVITATIONELLE

%_____________________________________________________________________________
%
% acceleration gravitationelle normale
 Catm.grav = 9.80655;
%_____________________________________________________________________________
%
%
%constante de gaz
 Catm.Rgazparfait=287.053;
 Catm.gammacpscv = 1.4 ;
 
%_____________________________________________________________________________

% atmosph�re standard 

% altitude H={0; 11000m}
 Catm.pression0=101325;
 Catm.mvol_0 = 1.225 ;

 Catm.kpression1=22.5576934e-6;
 Catm.alfap1=5.2558774;
 Catm.Temperature0=288.15;
 Catm.kTemperature1=0.0065;
 Catm.Altitude1=11000;
%_____________________________________________________________________________
%
% altitude H={11000m; 20000m} 
 Catm.pression2=22632;
 Catm.alfap2=-157.688446e-6;
 Catm.Temperature2=216.65;
 Catm.Altitude2=20000;
%_____________________________________________________________________________
%
% altitude H={20000m; 32000m}
 Catm.pression3=5474.9;
 Catm.kpression3=4.6157398e-6;
 Catm.alfap3=-34.1632031;
 Catm.kTemperature3=0.001;
%_____________________________________________________________________________

%
% viscosite
% !!! ancienne valeure fausse est VisDyn00=1.487e-6 !!!
 Catm.VisDyn00=1.487e-6;
 Catm.TVisDyn=110.4;
 Catm.aVisDyn=1.5;
%_____________________________________________________________________________


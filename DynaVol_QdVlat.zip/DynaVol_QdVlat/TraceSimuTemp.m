function S=TraceSimuTemp(Temps,Etats,DefTrace,Legendes) 

% Trac�s d'une simulation temporelle 
% Ce programme trace les �tats (Etats)
% en fonction du temps (Temps)
%  
% "TraceSimuTemp.m "
%PROGRAMME : " TraceSimuTemp.m "
%_____________________________
% "Etats" repr�sente l'ordonn�e  "y" des courbes � tracer et 
% il contient la simulation globale Etats(:,if,1),
% ou la "premi�re" courbe,
% et ensuite les simulations modales (i) Etats(:,if,1+i)
% Ce sont, pour les courbes � tracer, les valeurs de "y"
% Alors que "Temps" repr�sente l'abscisse "x", 
% pour les courbes � tracer, les valeurs de "x".
% Etats(it,if,ic) :
% it : indice du temps ou de "x"
% if : indice de l'�tat ou du N� de figure � tracer
% ic : indice du mode ou du N� de la courbe � tracer
% sur la figure "if"
% Ce programme peut donc tracer "nif" figures diff�rentes
% et sur chaque figure il peut tracer "nic" courbes diff�rentes.
% Par exemple :
% Etats(:,1,1) trace une figure avec une seule courbe
% Etats(:,1,2) trace une figure avec deux courbes
% Etats(:,2,1) trace deux figures avec une seule courbe par figure
% Etats(43,2,3) c'est la valeur en "y" du point de la figure 2 
% sur la courbe 3, pour la valeur du Temps(43) (ou de "x") 
%_____________________________%
% Les deux derniers arguments "DefTrace" et "Legendes"
% sont optionnels. "TraceSimuTemp" peut �tre appel� sous
% les deux formes suivantes :
%  	[S]=TraceSimuTemp(t,X,DefTrace) ; 
%	[S]=TraceSimuTemp(t,X) ; 
%_____________________________%
% D�finition des trac�s (c'est une structure) 
% Voir plus loin les arguments par d�faut pour la d�fintion 
% DefTrace.choix.itrac
% DefTrace.choix.VChFig
% DefTrace.choix.LW.en
% DefTrace.choix.LW.eu
% DefTrace.choix.nCol
% DefTrace.echelle.eyFig
% DefTrace.echelle.exFig
% DefTrace.unite.VUnFig
%
%_____________________________%%
% structure de L�gendes 
%	Legendes.Fig
%	Legendes.Titre
%	Legendes.Modes
%	Legendes.Simu
%	Legendes.X
%_____________________________
% 1�re version en octobre 2001 par JL Boiffier
% 2�me version en septembre 2003 par JL Boiffier
% avec les am�liorations suivantes : 
% - mise sous forme de fonction
% - pilotage des �chelles en x et y
% - choix des courbes et du nombre
% - possibilit� de tracer sur une ou deux colonnes
% - valeurs par d�faut d'arguments
%
%fprintf('nargin %d \n',nargin);


% Nombre de p�les ou nombre de modes : "npol"
	% deux valeurs propres complexes conjugu�es 
	% font un p�le
[nTempsTrash,nEtat,npolp] = size(Etats);
% X=Etats contient la simulation globale Etats(:,jp,1)
% et ensuite les simulations modales (i) Etats(:,jp,1+i)
% donc npolp = npol +1 (=i+1)
%npolp = npol +1 ;
npol = npolp - 1 ;
% On d�finit le nombre de courbes � tracer "nCourb" 
% sur chacune des figures.
% "nCourb" est �gal au nombre de p�le+1, ce sera utilis�
% lorsque nous aurons une seule courbe, pour 
% supprimer la l�gende inutile � distinguer les courbes.
nCourb=npolp;

 	% On utilise le nombre de p�le pour g�rer le trac�
	% des simulations modales. Si "npol=0", la boucle de 
	% trac� des simulations modales est neutralis�e.
	% Toutefois, pour la simulation globale, on conserve
	% l'�criture des modes en bas de page, pour information
	% "npolt" ? t pour trac�.
%____________________________________________________
% V�rification des tailles des vecteurs temps
[nTemps,mTrash]  = size(Temps);
 if nTemps == nTempsTrash
	%% Tout va bien
else 
	texte =['\n Les tailles du temps sont diff�rentes  \n'] ;
	fprintf(1,texte);
		fmt='%5.1f %5.1f';
	fprintf(1,fmt,nTemps,nTempsTrash);
end

%_____ Arguments par d�faut ___________
% Si seulement les deux ou trois premiers arguments 
% "Temps" et "Etats" ou "Temps", "Etats" et "DefTrace"
% Etablissement des __L�gendes__ par d�faut

if (nargin==3) | (nargin==2)

for j=1:nEtat
	strX(1,1)={'Etat '};
	aa={'N ' int2str(j)};
	strX(2,1)=cellstr([aa{1} aa{2}]);
	strX(3,1)={'  Unite ?? '};
	Legendes.Fig(j,:) = strX(:) ;
end

Legendes.Titre = {'\fontname{times}\it{Simulation temporelle par  modes et en fonction du temps en secondes (s)}'} ;  
 
	for jj = 1:npolp
		if jj==1 
			aa =[' Simulation globale' ' '];
		else
			aa=['Mode N' int2str(jj-1)];
		end
		strTP=cellstr(aa);
		Legendes.Modes(jj)= strTP; 
	end
Legendes.Simu= {' '};
Legendes.X= {' Temps ou X '} ;

end % of if (nargin==3) | (nargin==2)

%_____________________________________
% Si seulement les deux premiers arguments Temps et Etats
%	if nargin==2 

% Les unit�s = 1 pour chacun des �tats
Dft_VUnFig = ones(1,nEtat);
% Le trac� de toutes les courbes : simulation globale et modale
 Dft_itrac =2 ;
% Le choix des �tats � tracer = tous les �tats dans l'ordre
 for iv = 1:nEtat
Dft_VChFig(iv) = iv;
 end

% Le nombre de colonne de trac�s = 1
 Dft_nCol = 1 ;

% L'�chelle en y
Dft_eyFig = 1;
% L'�chelle en x
 Dft_exFig = 1;

% L'�chelle de l'�paisseur du trac� nominal
 Dft_LW.en = 1 ;
% L'�chelle de l'�paisseur du 1er trac� (simu global)
 Dft_LW.eu = 1 ;

%	end % of if nargin==2

% Modification suivant la proc�dure :
%%LW.en     = eval('DefTrace.choix.LW.en','LW.endft') ;
% etc 
% Cela permet, de d�finir les "DefTrace" d'apr�s 
% les valeurs donn�es en arguments "DefTrace.choix.LW.en"
% et si cet argument est vide, "LW.en" prend la 
% valeur par d�faut "LW.endft"
% Alors on peut remplacer le "if nargin==2" 
% par la d�finition de toutes les valeurs par d�faut
% 
% FAIRE DE MEME POUR LES "Legendes"

nColonne =eval('DefTrace.choix.nCol','Dft_nCol'); 
E_eyFig =eval('DefTrace.echelle.eyFig','Dft_eyFig');
E_exFig =eval('DefTrace.echelle.exFig','Dft_exFig');
LW.en =eval('DefTrace.choix.LW.en','Dft_LW.en');
LW.eu =eval('DefTrace.choix.LW.eu','Dft_LW.eu');
%
% ______ fin des arguments par d�faut ______________

%________ Premi�res initialisations _________________
itrac =eval('DefTrace.choix.itrac','Dft_itrac');
%____________________________________________________


% Pour le trac�, les modes sont dans Etats=X(:,jp,i)
% i pour les diff�rents modes 
% et i=1 pour la simu globale X(:,jp,1)
% i=2,npol+1 pour les simus modales
%for i = npoltinit:npoltp

% Globale : 
% la simulation classique, l'�tat r�el = somme des modes
% Modale : simulation de chacun des modes
% Pas de trac� des modes si "itrac==1"
%itrac = 1 ; % simulation temporelle globale seule
if itrac==1 
	npoltinit = 1 ;
	npolt=0; npoltp = npolt +1; 
%itrac = 2 ; % simulation temporelle globale et modale
elseif itrac==2 
	npoltinit = 1 ;
	npoltp = npolp ; npolt = npol ;
%itrac = 3 ; % simulation temporelle  modale seule
elseif itrac==3
%	npoltinit = 2 ; % cette m�thode ne marche pas
% ie ne pas tracer la simu globale.
% On choisit de la tracer mais invisible
% blanche "w" et sans trait "  "=rien
plotchar(1,:)= ['w  '];
	npoltinit = 1 ;
	npoltp = npolp ; npolt = npol ;
end 

%Vnpoltest=[npoltinit npoltp npolt]


%%_______ D�finition des lignes des courbes __________

plotchar=...
['k- ';'r- ';'b-.';'m--';'b- ';'b: ';'b-.';'b--';...
 'r- ';'r: ';'r-.';'r--';'m- ';'m: ';'m-.';'m--';...
 'c- ';'c: ';'c-.';'c--';'g- ';'g: ';'g-.';'g--';...
 'k- ';'k: ';'k-.';'k--';'b- ';'b: ';'b-.';'b--';...
 'r- ';'r: ';'r-.';'r--';'m- ';'m: ';'m-.';'m--';...
 'c- ';'c: ';'c-.';'c--';'g- ';'g: ';'g-.';'g--';...
 'w  '];

%%_______ D�finition des �paisseurs des courbes __________
LWnominal = 0.8*LW.en ;
plotLW = LWnominal*ones(1,16);
plotLW(1) = 0.8*LW.eu ; % �paisseur pour la premi�re courbe
%plotLW = [0.5 0.8 0.8 0.8 0.8 0.8 0.8 ];
%%________________________________________


%___________________________________________________________
% ______ Mise en forme des figures  ______________
%___________________________________________________________

%______ Origines et tailles des subfigures ______________ 
	% Facteur d'�chelle sur la largeur des subfigures
eexFig = min(1,E_exFig); 
	% Hauteur nominale des subfigures
DyfigoN = 0.12 ;
DyfigoN = 0.18 ;
	% hauteur des subfigures
Dyfigo = E_eyFig*DyfigoN ;
	% espace entre les deux colonnes
Dx2cfigo = 0.05 ;
	% Marge � droite
Dxmargedr = 0.05 ;
	% Marge en haut des figures
Dymargeht = 0.002 ;

%%___ Si une colonne
		if nColonne == 1
	 % Origine en x des subfigures
	xc1figo = 0.2 ;
	 % espace vertical entre les subfigures
	Dyefigo = 0.03 ; 
	% largeur des subfigures
	Dx = 1-(Dxmargedr+xc1figo) ;
	Dxcfigo = eexFig*Dx ; 

%%___ Si deux colonnes
		elseif nColonne == 2
	 % Origine en x des subfigures 1�re colonne
	xc1figo = 0.05 ; % = Marge � gauche
	 % espace vertical entre les subfigures
	Dyefigo = 0.04 ;
	% largeur des subfigures
	Dx = (1-(Dxmargedr+xc1figo+Dx2cfigo))/2 ;
	Dxcfigo = eexFig*Dx ;
	 % Origine en x des subfigures 2�me colonne
	xc2figo = xc1figo+Dxcfigo+Dx2cfigo ; 
		end

%____ Positions des Textes de l�gendes des subfigures ___________ 
		if nColonne == 1
% Position en  x des textes
	xc1texto = 0.05 ; 
% position en hauteur des textes de l�gendes des subfigures
	% dans la marge de gauche au milieu de la figure
	Dytexto = 0.66*Dyfigo ;

		elseif nColonne == 2
% Position en  x des textes
	%	xc1texto = 0.05 ;
	xc1texto = 0.1 ; 
	xc2texto = xc1texto+Dxcfigo+Dx2cfigo  ; 
% position en hauteur des textes de l�gendes des subfigures
	% Juste au dessus de la figure
	Dytexto = Dyfigo + 0.01 ;
		end


%____ Positions du cadre des Textes de l�gendes des trac�s (courbes) ___________
% positionn�s sous les figures
% D�finition des coordonn�es du cadre o� seront les l�gendes.
% Ces valeurs d�finissent la position (x,y) et la taille (Dx,Dy)
% du cadre (cartouche) dans lequel les l�gendes seront �crites

xtextmod = 0.005 ;
xtextmod = 0.15 ;
%ytextmod = 0.05 ;
ytextmod = 0.01 ;
ytextmod = 0.025 ;
Dxtextmod = 0.9 ;
%Dxtextmod = Dx;

%Si une seule courbe, pas de l�gende de courbe
% donc on r�duit la hauteur du cartouche
	if nCourb==1
Dytextmod = 0.03 ;
	else
Dytextmod = 0.07 ;
	end  

%____ Positions des l�gendes des trac�s (courbes)  _____________
% Longueur du trac� dans la l�gende du bas de page,
% des symboles associ�s � la courbe de chacun des modes
% Ces positions sont d�finies en relatif (%) par rapport
% � la dimension du cadre d�fini par les "xtextmod" etc

%Dxlegend = 0.25 ;
%
Dxlegend = 0.20 ;

% Position en "x" de la premi�re l�gende
xlegend0 = 0.05 ;
% Longueur en "x" de chacune des l�gendes
DxlegendL = Dxlegend - 0.05 ;

%Si une seule courbe, on d�cale vers le bas
% la l�gende du texte associ�es � la simulation
% Legendes.Simu
	if nCourb==1
Dylegend = 0.0 ;
DylegendS = 0.2 ;
	else
Dylegend = 0.2 ;
DylegendS = 0.4 ;
	end  


% Position en hauteur du texte des modes ou des courbes
ylegend = 0.05 ;
% Position en hauteur du trac� des symboles des modes
ylegendp = ylegend + Dylegend ;
% Position en hauteur des l�gendes associ�es � la simulation
ylegendS = ylegendp + DylegendS ;


%________Unit� des �tats trac�s (facteur multiplicatif)
%%VUF=DefTrace.unite.VUnFig;
VUF=eval('DefTrace.unite.VUnFig','Dft_VUnFig');


%____________________________________________________
%   Calcul du nombre de figures
%____________________________________________________
%
%______ Nombre de figures maximales sur une seule colonne 
%%yfigo(j) = Dyefigo + Dytextmod + (j-1)* (Dyfigo + Dyefigo);
%% yfigo(nEtat) <=1 ; % pour j=nEtat=nFigMax
nFigMax =fix((1-Dymargeht-(Dyefigo + Dytextmod))/(Dyfigo + Dyefigo));

%______ Nombre de figures demand�es et Choix de ces figures
VCF=eval('DefTrace.choix.VChFig','Dft_VChFig');
[nT,nFigD]=size(VCF);

%_____ Calcul du nombre de figures par colonne 
% si une seule colonne 
			if nColonne == 1
	% Nombres de figures retenues
	% Le minimum des trois demandes possibles
	VnFig=[nFigD,nEtat,nFigMax];
	nFigC1 = min(VnFig);
	nFigC2 = 0 ;
	%% On n'est peut �tre pas obliger de limiter par le nombre 
	%% d'�tats si on veut r�p�ter deux fois le m�me ?
			end 

% si deux colonnes 
			if nColonne == 2
	% Nombres de figures demand�es sur la colonne 1
		nFigDC1 = round(nFigD/2 + 0.1) ;
	% Nombres de figures demand�es sur la colonne 2
		nFigDC2 = round(nFigD/2 - 0.1) ;
	% Nombres de figures retenues
	% Le minimum des trois demandes possibles
	VnFig=[nFigDC1,nFigMax];
	nFigC1 = min(VnFig);
	VnFig=[nFigD-nFigC1,nFigMax];
	nFigC2 = min(VnFig);
			end 
% Nombre total de figures 
	nFig = nFigC1 + nFigC2 ;
%_________________________________________________________




%_____ Vecteurs des positions des textes et figures ___________
for j=1:nFigC1 
	yfigo(j) = Dyefigo + Dytextmod + (j-1)* (Dyfigo + Dyefigo);
	ytexto(j) = yfigo(j) + Dytexto; 
end

% Position en  "x" du texte de l'abscisse "Temps" ou "X"
	xc1textox = xc1figo + Dxcfigo ;
	xc2textox = xc1textox+Dxcfigo+Dx2cfigo  ; 
% position en hauteur "y" du texte de l'abscisse "Temps" ou "X"
	% Juste en dessous de la premi�re figure
	ytextox = yfigo(1) - 0.016 ;


%______ L�gendes de figures sur une seule ligne au lieu de 3 lignes
% si sur deux colonnes 
% si deux colonnes 
			if nColonne == 2
		for j=1:nFig
	AA=Legendes.Fig(j,:);
	[nl,nc]=size(AA);
%%______ Concat�nation sur une ligne ___________
% Cela reste un "cell" avec {j}, mais les espaces disparaissent
	%LegFigLignCell{j}=strcat(AA{1},AA{2},AA{3}); 
% Cela devient un "char"  mais on garde les espaces
		%aa=[AA{1} AA{2} AA{3}]; % c'est un "char"
% on revient en "cell" par cellstr
	%%Legendes.Fig(j)=cellstr([AA{1} AA{2} AA{3}]);

% On construit la ligne par concat�nation sur des "char"
		AAC=[];
	for inc = 1:nc 
		AAC =[AAC AA{inc}];
	end % of for inc = 1:nc
% On passe des "char" au "cell" par "cellstr"
LegFigLign(j)=cellstr(AAC);
  
	% si un "char" au lieu d'un "cell" :
	%LegFigLign(j,:)=[AA{1} AA{2} AA{3}]; 

		end % du for j=1:nFig %% L�gendes de figures
			end % du if nColonne == 2

%____________________________________________________
%____________________________________________________
%%   LES TRAC�S
%____________________________________________________
%____________________________________________________
%______ Axes  ______________
haxes=axes('Position',[0 0 1 1], 'Visible','off') ;
%h=axes('Position',[0 0 1 1], 'Visible','on') ;


%_____ Balayage sur les �tats ________________________________
% Une subfigure par �tat, on commence par le bas de la page
% o� se trace le dernier �tat

%% Premi�re colonne (la seule si option une seule colonne)
nFig_final = nFigC1; nFig_initial = 1 ;
for j=nFig_final:-1:nFig_initial 
	jyf=j-nFig_initial+1;
	axes('Position',[xc1figo yfigo(jyf) Dxcfigo Dyfigo]) % ligne axe 1
 	jp= nFig_final+nFig_initial-j;
	%______ Balayage sur les modes ___________
		% Chaque mode est trac� sur la subfigure
		% dont le cadre a �t� d�fini en ligne " axe 1 "
	for i = 1:npoltp
	plot(Temps,VUF(VCF(jp))*Etats(:,VCF(jp),i),plotchar(i,:),...%
		'linewidth',plotLW(i));
		if i==1 grid on; hold on ; end
	end %___ Fin du balayage sur les modes ________________
end %_____ Fin du Balayage sur les �tats ________________________

% si une deuxi�me colonne 
			if nColonne == 2
%% Deuxi�me colonne 
nFig_final = nFigC1+nFigC2; nFig_initial = nFigC1+1 ;
for j=nFig_final:-1:nFig_initial 
	jyf=j-nFig_initial+1;
	axes('Position',[xc2figo yfigo(jyf) Dxcfigo Dyfigo]) % ligne axe 1
 	jp= nFig_final+nFig_initial-j;
	%______ Balayage sur les modes ___________
		% Chaque mode est trac� sur la subfigure
		% dont le cadre a �t� d�fini en ligne " axe 1 "
	for i = 1:npoltp
	plot(Temps,VUF(VCF(jp))*Etats(:,VCF(jp),i),plotchar(i,:),...%
		'linewidth',plotLW(i));
		if i==1 grid on; hold on ; end
	end %___ Fin du balayage sur les modes ________________
end %_____ Fin du Balayage sur les �tats ________________________

			end % de if nColonne == 2

%______ Trac� des symboles et l�gendes des courbes (Modes) ___________________
%_______ Texte sous l'ensemble des figures 
%hold off;
set(gcf,'currentaxes',haxes)
 axes('Position',[xtextmod ytextmod Dxtextmod Dytextmod])

%
% Vecteur " Altitude " des symboles utilis�s pour le trac� des courbes 
ylegp = [ylegendp ylegendp];
xlegend=xlegend0;

%%___ Si une seule courbe, on ne trace pas les l�gendes des courbes
	if nCourb ~=1

npolpu = npol+1;
for jj = 1:npolpu 
	% Vecteur " Longueur " des symboles utilis�s pour le trac� des courbes 
	xlegendchar = [xlegend xlegend+DxlegendL];
	% Trac� des symboles utilis�s pour le trac� des courbes 
%	if itrac ~= 1 % ne trace pas les symboles si simulation globale
		plot(xlegendchar,ylegp,plotchar(jj,:),'linewidth',1.2) 
		hold on;

%	end
	% Trac� des l�gendes associ�es � chacun des trac�s des courbes
	% on �crit les modes m�me si simulation globale 
		%(d'o� "npol" au lieu de "npolt" au "for jj = 1:npol")
		text(xlegend,ylegend,Legendes.Modes(jj),'Fontsize',10)
		xlegend = xlegend + Dxlegend ; 
end
	end % of if nCourb ~=1

%_____ Trac� des l�gendes associ�es � la simulation 
% Commentaires et param�tres caract�ristiques de la simulation
		text(xlegend0,ylegendS,Legendes.Simu,'Fontsize',12)

% On force les axes � l'unit� apr�s les trac�s. 
% Si on le fait avant les valeurs limites sont modifi�es
% par les trac�s, m�me si on fait "axis manual" ou "axis(axis)"
axis([0 1 0 1]);
%axis(axis)

%
 axis('off')
% axis('on')
hold off;
%______ Fin des Trac�s des symboles et l�gendes des courbes ___________________

%______ Trac� du titre g�n�ral et des l�gendes des subfigures _______________
set(gcf,'currentaxes',haxes)
	%______ Trac� du titre g�n�ral en haut des subfigures
 	ytextTitre = yfigo(nFigC1) + Dyfigo + Dyefigo ;
	text( xc1figo , ytextTitre , Legendes.Titre , 'Fontsize',12)

	%______ Trac� des l�gendes des subfigures ________________
%% Premi�re colonne (la seule si option une seule colonne)
nFig_final = nFigC1; nFig_initial = 1 ;
for j=nFig_final:-1:nFig_initial 
	jyf=j-nFig_initial+1;
 	jp= nFig_final+nFig_initial-j;
 			if nColonne == 1
	text( xc1texto , ytexto(jyf) , Legendes.Fig(VCF(jp),:) , 'Fontsize',10) 
			elseif nColonne == 2
	text( xc1texto , ytexto(jyf) , LegFigLign(VCF(jp)) , 'Fontsize',10) 
			end
% L�gende de l'abscisse uniquement sous la figure du bas
	if j == nFig_initial
text(xc1textox,ytextox,Legendes.X,'Fontsize',10,'VerticalAlignment','top','HorizontalAlignment','right')
	end
end%_____ Fin du Balayage sur les �tats
 

% si une deuxi�me colonne 
			if nColonne == 2
%% Deuxi�me colonne 
nFig_final = nFigC1+nFigC2; nFig_initial = nFigC1+1 ;
for j=nFig_final:-1:nFig_initial 
	jyf=j-nFig_initial+1;
 	jp= nFig_final+nFig_initial-j;
	text( xc2texto , ytexto(jyf) , LegFigLign(VCF(jp)) , 'Fontsize',10) 
	if j == nFig_initial
text(xc2textox,ytextox,Legendes.X,'Fontsize',10,'VerticalAlignment','top','HorizontalAlignment','right')
	end
end %_____ Fin du Balayage sur les �tats 
			end % de if nColonne == 2




%%_______________________________________________________
%% Commentaires de fin de programme
%%_______________________________________________________
%% Dans cette s�quence :
%%	%______ Balayage sur les modes ___________
%%		% Chaque mode est trac� sur la subfigure
%%		% dont le cadre a �t� d�fini en ligne " axe 1 "
%%	for i = 1:npoltp
%%
%	for i = 1:npoltp
%%%	for i = npoltinit:npoltp
%%	for i = npoltp:-1:npoltinit 
%		if itrac==3 & i==1 % Voir comment bas de page�
%		plot(t,rad2deg*X(:,jp,i),plotchar(49,:),'linewid%th',plotLW(i));
%		else
%		plot(t,rad2deg*X(:,jp,i),plotchar(i,:),'linewidth',plotLW(i));
%		end 
%% nous avons ajout� la condition "if itrac==3 & i==1 "
%% pour tracer uniquement les simulations modales 
%% en tra�ant la simulation globale en transparence gr�ce au 
%% plotchar(49,:)='w ' blanc sans trait.
%% Sinon, je ne sais pas pourquoi, on ne voyait en trac� que le premier
%% et pas les autres ????

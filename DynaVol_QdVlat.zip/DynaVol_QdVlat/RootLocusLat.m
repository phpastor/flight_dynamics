function RootLocusLat(Aetat, Betat, Cetat, Klocus) 


Sgrid.Damping = 0:0.1:1;
Sgrid.Frequency = 0.1:0.1:0.5;
Sgrid.FrequencyUnits ='Hz' ;
Sgrid.GridLabelType ='damping' ;

InputName  = { '{\delta}l', '{\delta}n'} ;
OutputName = { '\beta' , 'r' , 'p', '\Phi' };


for ii=1:2 % boucle sur l'entr�e

  inname = InputName{ii} ;

  for jj=1:4;	% boucle sur la mesure

    outname = OutputName{jj} ;

    if Klocus(ii,jj) 

      figure

      rlocus100p(Aetat, Betat(:,ii), Cetat(jj,:), 0, [0:0.01:2]  , 'r.')  ;
      hold on
      rlocus100p(Aetat, Betat(:,ii), Cetat(jj,:), 0, [0:0.1:2]   , 'k+')  ;

      rlocus100p(Aetat, Betat(:,ii), Cetat(jj,:), 0, [0:-0.01:-2], 'g.')  ;
      rlocus100p(Aetat, Betat(:,ii), Cetat(jj,:), 0, [0:-0.1:-2] , 'k+')  ;

      rlocus100p(Aetat, Betat(:,ii), Cetat(jj,:), 0, 0           , 'bs')  ;

      axis([-3 0.5 -1.75 1.75])
      axis('square')
      spchart(gca,Sgrid) ;

      title(['Retour de ', outname, ' sur ',inname],'FontSize',12)

    end

  end

end

%=====================================================
%
%   Initialise du format des trac�s
%	
% 	Ce fichier doit execut� en debut de session
%
%====================================================

%   JLB 10 novembre 2002 
%   PV   3 D�cembre 2014


%----------------------------
%
%  D�fauts pour les trac�e
%
%---------------------------

   FontName =  'Times' ;
   FontSize = 10 ;

 % Position en centim�tres

  Ox =  2.0 ; % marge gauche-droite
  Oy =  4.5 ; % marge haute basse

  Px = 21.0 ; % Taille papier
  Py = 29.7 ; 
  Lx = Px - 2*Ox;
  Ly = Py - 2*Oy;
 
%  Configuration impression

  PaperOrientation = 'portrait' ;
  %PaperType        = 'a4letter'; % ne semble pas exister dans la doc standard
  PaperType        = 'A4';

  if strcmp(get(0,'DefaultFigurePaperUnit'), 'inches')
     PaperPosition    = [ Ox Oy Lx Ly ] /2.54 ; % en inches
  else
     PaperPosition    = [ Ox Oy Lx Ly ]  ; % en centimetres
  end

%  Configuration figure

  Position         = [ Ox+13 Oy-2.5 Lx Ly] *85/2.54; % 85 pixels / inch

  % Il faut que le 85 pixels/inch correspondent � la r�alit� sinon
  % il n'y a pas correspondance entre les longeurs demand�es (en cm, 
  % pas exemple) et ce qui est imprim�. 
  % Fair un exemple test, pour tester cela : 
  %    figure
  %    L1 = get(gcf,'Position')
  %    set(gcf, 'Units', 'centimeters')
  %    L2 = get(gcf,'Position')   
  %    L1 ./ L2 ==> pixels/cm 
  
  % Au niveau des valeurs par d�faut, on ne peut effectuer des changements
  % d'unit� car les champs "Position" ne sont remis a jour
  % que sur des objects existants.
  %  Ainsi la "PaperPosition" doit �tre donn�e en inch .


%  Stockage des d�fauts

  set(0,  'DefaultFigurePaperType',        PaperType        ,...
          'DefaultFigurePaperOrientation', PaperOrientation ,...
          'DefaultFigurePaperPosition',    PaperPosition    ,...
          'DefaultFigurePosition',         Position)

  set(0, 'DefaultAxesFontName',FontName,  ...
         'DefaultAxesFontSize',FontSize,  ...
         'DefaultAxesBox',     'on'    ,  ...
         'DefaultAxesXgrid',   'on'    ,  ...
         'DefaultAxesYgrid',   'on'        )

  set(0, 'DefaultTextFontName',FontName, ...
         'DefaultTextFontSize',FontSize)

%-----------------------------------------
% 
%   Accus� d'ex�cution
%
%------------------------------------------

disp(' Ex�cution de InitTraces effectu�e ')
disp(' Je vous souhaite un bon BE '      )
disp(' ')

disp('La r�ponse � toutes vos questions :')
why
disp(' ')



 
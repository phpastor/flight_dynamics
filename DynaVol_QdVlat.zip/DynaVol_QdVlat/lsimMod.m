
function [Ytri,Xtri,T,VP] = lsimMod(sys,u,t,x0)

% LSIM_MOD   modal decomposition, simulation
%-----------------------------------------------------------------
%function [Y,X,T,VP] =
%		= lsimMod(sys,u,t,x0)
% PURPOSE
% Simulation of the modal decomposition.
%
% SYNOPSIS
% [Y,X,T,VP] = 
%    lsimMod(sys,u,t,x0)
%
% DESCRIPTION
% This functions simulates the modal decomposition of one entry of
% the  state vector or of one entry of the measurements vector. If
% it is invoked with one  or more output arguments, the simulation
% is  not  displayed  but  the  poles are sorted out, ordered with
% respect  to their L_2 contribution. Dominant modes can be ident-
% ified in that way.
%
% CAUTION
% If this function is used for analysing dominant modes: sometimes
% modes  that  appear  to  be  dominant  cancel  each  others. For
% example
%    sss = ss(tf(1,[1 1])+0.1*tf(1,[1 2 2])-tf(1.01,[1 1.01]));
%    lsimMod(sss,'u1',10,0,'y1');
%    lsimMod(sss,'u1',10,0,'y1',[3 3]);
% The  dominant mode is -1+j (-1 and -1.01 have symetric effects).
%
% INPUT ARGUMENTS
% sys,u,t,x0    Same  as  for  lsim  OR u = 'u1' or 'u2' etc for a
%               unit step at input_1 or input_2 etc.  In this case
%               t indicates the length of the simulation.
%
% OUTPUT ARGUMENTS
% Xtri(:,jetat,1+kmode) 
%		donne la simulation temporelle de 
%		la participation modale du mode num�ro "kmode" 
%		sur l'�tat num�ro "jetat"
% Xtri(:,:,1) 
%		donne la simulation temporelle globale du syst�me 
%		par exemple : X(:,3,1) donne la simulation globale 
%		(classique) sur l'�tat num�ro "3"
% Ytri(:,jsortie,1+kmode) idem Xtri(:,jetat,1+kmode) pour les sorties
%		donne la simulation temporelle de 
%		la participation modale du mode num�ro "kmode" 
%		sur la sortie num�ro "jsortie"
% 	Le premier indice est celui du temps X(1:10,3,1) donne les 
% 	"10" premiers points de la simulation globale ("1") 
% 	l'�tat num�ro "3"		
% Xtri, Ytri : Les participations modales sur les �tats et sur les sorties 
% 	sont tri�es suivant l'ordre croissant 
% 	de la distance des modes � l'origine.
% 	Par exemple X(:,4,2) donne la simulation du mode 1 (2=1+1) 
%	 pour l'�tat num�ro 4 
% 	et X(:,4,3) donne la simulation du mode 2 (3=1+2), 
% 	ce mode �tant plus loin de l'origine que le mode 1 
% T : vecteur temps 
% VP : structure contenant les valeurs propres
%	"VP(1).valeur" contient la valeur propre du mode num�ro 1
%	"VP(2).texte" est un string qui contient le texte associ� 
%	au mode num�ro 2. Exemple "\tau = 0.41 s" ou "T=2.1s \xi = 0.53"
%	exprim� sous forme de constante de temps, p�riode 
%	et amortissement r�duit
%
% See rmct and lsim, plot_res
%#
%-----------------------------------------------------------------
% % EXAMPLE, System:
%    a=[-1 0 0 0;0 -.1 -1 0;0 1 -.1 0; 0 0 0 -2]; d=0;
%    c=[eye(3,3) ones(3,1)]; b=[1 0;1 1;0 1;1 1];
%    sys = ss(a,b,c,d);
%
% % MODAL SIMULATION  of  the  step response of the second output
% % ('y2') the step being applied to the second input ('u2').
%    npol = 3;       %<- 3  number of displayed modes.
%    x0 = [1;1;1;1]; %<- initial state .
%    u=ones(100,1)*[0 1]; t=0.1*[0:1:99]';
%    lsimMod(sys,u,t,x0);
%    pause
%
% % Alternative shortcut
%    lsim_mod(sys,'u2',10,x0,'y2',npol);

% Author JF Magni: magni@cert.fr de la fonction "lsim_mod"  
% Revised 08-August-2000
% La fonction "lsimMod" utilise le coeur de "lsim_mod"  pour 
% le calcul de la participation modale.
% Elle a �t� adapt�e par JL Boiffier fin novembre 2001 (boiffier@cert.fr)
% pour donner la participation modale sur l'ensemble des �tats et sorties. 
% Les sorties sont tri�es suivant l'ordre croissant 
% de la distance des modes � l'origine.


%_____ Nombre et test du nombre d'argument d'entr�e ____________
ni = nargin;
% Erreur si le nombre d'arguments n'est pas compris entre 3 et 4
error(nargchk(3,4,ni)) 

%_____ Matrices et taille du syst�me ___________________
[a,b,c,d] = ssdata(sys);
[ny,nx] = size(c);
[pp,mm] = size(d);
[nn,nn] = size(a); % Ordre du syst�me
	%____ Partie r�elle des matrices
	a = real(a); b = real(b); c = real(c); d = real(d);
%_____ Vecteur des conditions initiales
% mise � z�ro s'il n'est pas dans les arguments
if x0 == 0; x0 = zeros(size(a,1),1); end;

%_____ Vecteur de l'entr�e si 'ui' est un string __________________
% si 'ui' est un string on reconstitue u(i) 
% sous forme d'un �chelon unit� 
% on d�finit aussi le vecteur temps
if u(1) == 'u'; % si 'ui' est un string
   lu = length(u); ui = str2num(u(2:lu)); %indice de l'entr�e 
   % vecteur ligne entr�e (1*mm nbre d'entr�es) "1" sur l'entr�e identifi�e
	uu = zeros(1,mm); uu(ui) = 1; 
   % matrice "u" � la taille de "d", une colonne de "1" sur l'entr�e identifi�e
	u = ones(100,1)*uu; 
	t = (t/100)*[0:1:99]'; % vecteur temps 
end;


%  Signal to be simulated and plotted
[npt,mpt] = size(u); 
% npt taille du vecteur temps (nombre de points de simulation)

%_______ Vecteurs propres "Vec" et valeurs propres "Val" _______________
% "Vec" vecteur propre � droite (A Vec =  Vec Val)
% "Val" matrice diagonale des valeurs propres
	[Vec,Val] = eig(a); 
% "Uec" vecteur propre � gauche Uec = Inverse(Vec) (Uec A = Val Uec)
	Uec = inv(Vec); % 

Val = diag(Val); % Vecteur colonne des valeurs propres

%_______ Tri et indices des valeurs propres _________
% K vecteur colonne des indices des p�les 
% la taille de K est �gale au nombre de p�les 
% i.e. que 2 valeurs propres complexes conjugu�es comptent pour un p�le
% par exemple "Val(K(:))" donne le vecteur des valeurs propres
% avec une seule valeur pour les modes complexes

	%_______ Recherche du nombre de p�les K _______
K  = [];  jj = 1;
% nvp nombre de valeurs propres 
nvp =length(Val); % si nvp n'est pas �gal � nn et nx il y a une erreur

while jj <= nvp;
	if imag(Val(jj)) == 0; % Modes r�els
		K  = [K;jj]; % Vecteur des indices des p�les
		jj = jj+1;
	else   %Modes complexes
		K  = [K;jj]; % Vecteur des indices des p�les
		jj = jj+2;
	end;
end;

[npol,mcv] = size(K); % npol nombre de p�le (1 p�le pour 2 VP imaginaires)
npolp = npol +1 ;


 	%______ Tri des modes
[Trash,IpermVal] = sort(abs(Val(K(:))));
	% sur la valeur absolue (distance � z�ro)
	% ValTri contient les valeurs propres tri�es par ordre croissant
	% et ne contient qu'une seule valeur propre
	% pour deux valeurs propres imaginaires conjugu�es
ValTri = Val(K(IpermVal(:)))  ;

	%_________ Deux normes pour le tri (non utilis�es) ______________
% mais ces normes classent sur la valeur du signal de sortie
% le classement n'est donc pas identique
% pour l'ensemble des sorties et des �tats
% c'est pourquoi elles ne sont pas utilis�es ici.
% Si on voulait les utiliser, il faudrait les inclure dans la boucle de 
% simulation modale
% infinity-norm
% [Y,I] = sort(abs(Ysi)); Ymax = Y(npt,:); [Y,I] = sort(abs(Ymax'));

% two-norm
% for jj = 1:ncv; Ymax(1,jj) = norm(Ysi(:,jj)); end;
% [Y,I] = sort(abs(Ymax'));

%_______ Dimensionnements et mise � z�ro ____________________
X = zeros(npt,nx,npolp);
Y = zeros(npt,ny,npolp);
sX = size(X);
sY = size(Y);

Xtri = zeros(npt,nx,npolp);
Ytri = zeros(npt,ny,npolp);

%_______ Simulation globale
[Yglob,T,Xglob] = lsim(sys,u,t,x0);

	% On place en position 1 du 3�me indice des sorties de la fonction lsimMod
	% la simulation globale 
Ytri(:,:,1) = Yglob; Xtri(:,:,1) = Xglob;
	%% cette op�ration est faite en fin de programme (cette fonction lsimMod)
	%% si on renomme X en Xtrie 
	% Ensuite on mettra les simulations par modes


%_______ Etat dans la base modale Xsi ______________
	% Xglob= Somme_i^n xsi_i v_i = Vec Xsi
	% Xsi = Inv(Vec) Xglob = Uec Xglob
Xsi = (Uec*Xglob');


%=========================================================
%  Boucles sur chacun des �tats et des sorties
%_________________________________________________________
% indice de l'�tat ou de la sortie � simuler
%ii = str2num(ixy(1,2:mii));
%............................................

%______ Simulation des �tats ___________
for jetat = 1:nx
	ci = zeros(1,nx); ci(jetat) = 1; % Cr�ation d'une matrice de sortie "c" 
	Xmodal = SiMod(Val,ci,Vec,Xsi);
% stockage de la simulation modale de l'�tat "jetat" pour 
% chacun des modes de 1 � npol 
	X(:,jetat,1:npol) = Xmodal ; %%  	
end

%______ Simulation des sorties ___________
for jsortie = 1:ny
	ci = zeros(1,nx); ci = c(jsortie,:); %Extrait de la matrice de sortie "c" 
	Ymodal = SiMod(Val,ci,Vec,Xsi);
	Y(:,jsortie,1:npol) = Ymodal; % 
end
	% v�rifier si tout "simplement" Y=c X
%=========================================================
%  FIN des Boucles sur chacun des �tats et des sorties
%=========================================================

%_______ Tri des sorties _________________________________
 % le tri se fait suivant les valeurs propres croissantes
 % on garde le premier terme (i=1), qui correspond � la 
 % simulation globale d�j� "enregistr�e"
for i = 2:npolp
	Xtri(:,:,i) = X(:,:,IpermVal(i-1)) ;
	Ytri(:,:,i) = Y(:,:,IpermVal(i-1)) ;
end

%______ Valeurs et L�gendes des Valeurs Propres _______________________
fmt='%7.2f '; % format du texte de la l�gende des VP

for j = 1:npol
	%_____ Valeurs des Valeurs Propres ___________
	VP(j).valeur = ValTri(j) ;
	%_____ Texte des l�gendes ________________
	% expression des valeurs propres en p�riode T, xi, et tau
	reelnum(j)=real(VP(j).valeur);
	imagnum(j)=imag(VP(j).valeur);

     if (imagnum(j) ~= 0)
		% abs(0) �a plante (Index into matrix is negative or zero) 
		% c'est pourquoi on ne prend pas le "abs" avant d'�tre 
		% sur un mode oscillant
		imagnum(j)= abs(imagnum(j)) ;
      	Periode(j) = 2*pi/imagnum(j) ;
		xlocal= (imagnum(j)/reelnum(j))^2;
		Amortreduit(j) = sign(-reelnum(j))*1/sqrt(1+xlocal);
		% Mise en texte 
		VVPxi = sprintf(fmt,Amortreduit(j)); % amortissement r�duit
		VVPT = sprintf(fmt,Periode(j)); % P�riode (r�elle)
	VP(j).texte=['T=' VVPT 's' '  \xi =' VVPxi];
	else
  		Tau(j) = - 1/reelnum(j) ;
		VVPTau = sprintf(fmt,Tau(j)); % Constante de temps
	VP(j).texte=['\tau = ' VVPTau 's'];
         end
end

%_______ Vecteur temps ___________________________________________
T = t ;



%***********************************************************
%  FIN du programme lsimMod
%***********************************************************
%_____________________________________________________________________
function Ymodal = SiMod(Val,ci,Vec,Xsi)

% Val vecteur des valeurs propres
% ci matrice de sortie (ligne correspondant � la sortie calcul�e par SiMod)
% Vec vecteur propre � droite
% Xsi = Uec*Xglob' Composante de l'�tat dans la base modale
%	%vecteur propre � gauche * vecteur Etat de simulation globale
%
% Ymodal une seule Sortie contenant les participations modales
	%  Ymodal(:,n) Participation � la simulation temporelle du mode n

% Initialisation � z�ro 
	cv = [];  jj = 1;

% nx nombre de valeurs propres 
nx =length(Val);

while jj <= nx;
	if imag(Val(jj)) == 0; % Modes r�els
		cvi = zeros(1,nx); cvi(jj) = ci*Vec(:,jj);
		cv = [cv;cvi];
		jj = jj+1;
	else		%Modes complexes
		cvijj = ci*Vec(:,jj);
		cvi = zeros(1,nx); cvi(jj) = cvijj; cvi(jj+1) = conj(cvijj);
		cv = [cv;cvi];
		jj = jj+2;
	end;
end;

Ymodal = real((cv*Xsi))';

% end % fonction SiMod









   

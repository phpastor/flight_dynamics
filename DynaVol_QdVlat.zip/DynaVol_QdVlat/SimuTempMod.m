%===========================================
%
% Simulation temporelle globale et par mode
%  du mouvement lat�ral
% 
%===========================================


%  Donn�es avion : g�om�trie, masse, a�rodynamique et moteur

 Avion = DonneesDC8(msVol,kCoef);

 % Extraction des champs (� changer par xstruct)

 TransfertDonnees;

% �quilibre longitudinal

  EquilibreLongi;

%   Matrices d'�tat :  Aetat,Betat,Cetat,Detat

SystemeEtatLateral ;

% Matrice d'�tat en boucle ferm�e

ABKetat = Aetat+ Betat*KBetat;

% Syst�me d'�tat 

sys = ss(ABKetat,Betat,Cetat,Detat) ;

%========================
% Simulation temporelle
%========================

if iTempRoot==1

  % Simulation globale et par modes

 [Y,X,T,VP] = lsimMod(sys, u, t, x0) ;

 % Trac� des courbes

 LegendeTraceST_Lat;

 DefTraceST_Lat ;

 figure

 TraceSimuTemp(t,X,DefTrace,Legendes) 


elseif iTempRoot==2

%====================================================================
% Lieu des racines
%====================================================================

	RootLocusLat(ABKetat, Betat, Cetat, LRKBetat) 

end


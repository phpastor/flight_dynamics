%=============================================
%
%	 Simulation temporelle des QdV lat�rales
%
%                  ou 
%
%         Trac� du lieu des p�les
%
%=============================================
 
%  Pour initialiser le format des trac�s, ex�cuter 
%               InitTraces
%  une seule fois en d�but de session


%  Choix du travail � effectuer

   SimuOuRoot = 1 ;   % Simulation temporelle
 % SimuOuRoot = 2 ;   % Lieu des p�les (root locus)

%-------------------------------
%
%  D�finition de la simulation 
%
%-------------------------------

 % Grandeurs qui seront trac�es

   % DonTrace = 1  ; % composantes de l'�tat lat�ral Xlat
     DonTrace = 2  ; % composantes de l'�tat Xlat et les contributions modales

 % Dur�e de la simulation (en secondes)

     TempsSimu = 20   ; 
   % TempsSimu = 50   ; 
   % TempsSimu = 100  ; 
   % TempsSimu = 1000 ;
  
 % Cas de vol 

     Altitude  =     0 ; % m�tres
   % Altitude  = 12000 ;

     Vitesse   =  125  ; % m/s
   % Vitesse   = 240   ; 

     MargeStat = 0.15 ; % positive = stable 
   % MargeStat = 0.10 ; 
   % MargeStat = 0.30 ;

 % �tat initial = valeurs � l'instant 0  des composantes de l'�tat Xlat
 % Unit�s : angles en degr�s, vitesse de rotation en deg/s

    % beta0 =  0  ; % d�parage 
      beta0 =  4  ;   

      r0    =  0  ; % lacet 

      p0    =  0  ; % roulis 

      phi0  =  0  ; % g�te
    % phi0  = 30  ;
 
 % Valeurs des braquages sur les gouvernes pour les entr�es �chelon
 % Unit�s : degr�s

      dl =   0   ; % ailerons
    % dl = - 5   ; 
    % dl = - 0.1 ;

      dn =   0   ; % direction
    % dn = - 5   ;

 %  Application de facteurs multiplicatifs 
 % 

      kSD  = 1    ; % Surface d�rive     : SD  = kSD  * SD_nominale
    % kSD  = 1/3  ; 
    % kSD  = 2    ; 

      kCnb = 1    ; % Stabilit� de route : Cnb = kCnb * Cnb_nominal
    % kCnb = 1/2  ; 
    % kCnb = 2    ; 
    % kCnb = 1/3  ; 

      kClb = 1    ; % Effet di�dre       : Clb = kClb * Clb_nominal
    % kClb = 1/2  ; 
    % kClb = 2    ; 

 % D�finition des gains de COMMANDE

    % Retours sur les ailerons dl

      kdlBeta =  0   ;  % dl = kdlBeta * beta

      kdlr    =  0   ;  % dl = kdlr    *  r

      kdlp    =  0   ;  % dl = kdlp    *  p

      kdlPhi  =  0   ;  % dl = kdlPhi  * phi
    % kdlPhi  =  2.1 ;

    % Retours sur la direction dn 

      kdnBeta =  0   ;  % dn = kdnBeta * beta
    % kdnBeta = -1.7 ; 
    % kdnBeta = -3   ;

      kdnr    =  0   ;  % dn = kdnr    *  r 
    % kdnr    =  1.5 ;
    % kdnr    =  2.5 ;

      kdnp    =  0   ;  % dn = kdnp    *  p

      kdnPhi  =  0   ;  % dn = kdnPhi  * phi
    % kdnPhi  = -1.3 ;


%----------------------------------
%
%  D�finition des lieux des racines 
%          � tracer
%
%----------------------------------

   % Mettre 0 ou 1 � la position du lieu des modes � tracer
   %    colonne : beta, r , p 
   %    ligne   : dl , dn 

   TabLieuMod = [ 1  1  1  1  ; ...
                  1  1  1  1  ] ; 


%-----------------------------
%
%  Lancement de la simulation 
%
%-----------------------------

    LancementSimulation

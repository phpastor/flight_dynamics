%Calcul de l'�quilibre en croisi�re d'un avion
% Ce calcul s'effectue apr�s avoir appel� les donn�es avion
% effectu� le transfert des donn�es sur les variables 
% simples standardis�es
% La s�quences d'appel est donc la suivante 
%	DonneesDC8;
%		(Avion = 'DC8' ; % �ventuellement)
%	TransfertDonnees;
%	Equi=Equilibre(12,240); % h,V Solution non retenue
%
%PROGRAMME : "Equilibre.m"


gravite = 9.80665 ;

% _________ Cas de vol ______________________

% D�fini dans le programme d'appel  
%VitVol = 240;          % vitesse en m/s
%AltVol= 12;           % altitude en km

%__________ Atmosph�re standard _____________
% D�fini dans le programme d'appel
rho0 = 1.225 ;
% La masse volumique rho est d�finie 
% par le programme d'appel (Cas de vol + Atmosph�re)
%%rho = rho0*(1 - 22.6e-3.*AltVol)^4.26;

sigma = rho./rho0 ;

% ______Calculs pr�liminaires __________________

Pdyn = (rho.*VitVol.^2)/2 ;

SPdyn = Pdyn.*Sref ;
SlPdyn =SPdyn*lref ;
lsv = lref/VitVol ;
gsv = gravite/VitVol ;


%______ Recherche de l'�quilibre - Cas de vol ______________
Cz = masse*gravite./SPdyn ;
%Alpha = Cz ./ Cza + A0 ;

% R�solution su syst�me de 2 �quations � 2 inconnues
% Cm=0 ,Cz = Cz et Alpha , dm
Aad = [Cma Cmdm ; Cza Czdm];
Bad = [-Cm0 ; Cz];
Xad = inv(Aad)*Bad ;
Alpha = Xad(1) + A0 ;
dm = Xad(2) ;

% Le pseudo �quilibre devra �tre introduit
% pour d�finir Gama.
% ici on suppose que l'on est en palier
 Gama = 0 ;    % en Vol en palier
Theta = Alpha + Gama ;    % en Vol en palier
Alphad = (180/pi)*Alpha;
dmd = (180/pi)*dm ;

Cx = Cx0 + ki.*(Cza*(Alpha-A0))^2; % coefficient de trainee

Cxa = 2.*ki.*Cz.*Cza ; % Gradient en alpha du coef de tra�n�e

Trainee = SPdyn.*Cx ;
Poussee = Trainee ;

dPousseeSdx = sigma.*Fm0.*VitVol^Lf ; %dF/dx
% position de la manette des gaz
dx = Poussee./dPousseeSdx ; 


finesse=Cz./Cx ;                     %finesse
finessep = finesse + tan(Alpha) ; 



%_____ D�finition des Trac�s de simulation lat�rale
%
% "DefTraceST_Lat.m"
% N�cessaire pour la simulation :
%[S]=TraceSimuTemp(Temps,Etats,DefTrace,Legendes)
%
%__________________________________


DefTrace.choix.itrac = itrac ; % "itrac" d�fini dans " InitSimulation.m"

% Le choix des �tats � tracer 

DefTrace.choix.VChFig = [1 2 3 4 ]; % Tous les �tats dans l'ordre

% DefTrace.choix.VChFig = [3 1 2 ];

% Le nombre de colonne de trac�s
%
 DefTrace.choix.nCol = 1 ;

% DefTrace.choix.nCol = 2 ;

% L'�chelle en y 

DefTrace.echelle.eyFig = 1;

% DefTrace.echelle.eyFig = 2;

% L'�chelle en x
%
 DefTrace.echelle.exFig = 1;

%DefTrace.echelle.exFig = 0.7;

% Les unit�s pour chacun des �tats

 DefTrace.unite.VUnFig	= rad2deg*[1 1 1 1 ];

% L'�chelle de l'�paisseur du trac� nominal (0.8)

 DefTrace.choix.LW.en = 0.7 ;

% L'�chelle de l'�paisseur du 1er trac� (simu global)

 DefTrace.choix.LW.eu = 2 ;


%__________________________________



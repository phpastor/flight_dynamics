%Transfert des donn�es d'un avion de nom 'Davion'
% de type structure vers les donn�es �quivalentes simples
% exemple 'Cnp = DC8.coef.Cnp;'

%PROGRAMME : "TransfertDonnees.m"


% Il faut en premier lieu, avant l'appel de ce programme,
% d�finir le nom de l'avion. Par exemple :
%  Avion = 'DC8' ;
% Cette ligne peut �tre incluse dans le fichier des donn�es
% par exemple dans "DonneesDC8.m"
% La s�quences d'appel est donc la suivante 
%	Donn�esDC8;
% �ventuellement si ce n'est pas dans "Donn�esDC8" :
%	(Avion = 'DC8' ; )
%	TransfertDonnees;



Geometrie=...
['lref ';'Sref ';'SE   ';'Sd   ';'b    ';'bE   ';...
 'd    ';'ym   ';'LA   ';'LE   '];
%Geometrie(2,:) = 'Cz   '
% Attention : les noms de coefs 'Cnp  ' doivent tous 
% avoir la m�me dimension, ici 5 

%___ Transfert des donn�es G�om�triques ________
for i = 1:size(Geometrie,1) 
	eval([Geometrie(i,:) '=' ...
		'Avion.geom.' Geometrie(i,:) ';']);
end

%_______ Choix pour le Transferts de Nom de l'Avion _____
% si le nom de l'avion est transmis directement sous la forme 
% Avion = 'DC8' ; % Alors on peut �crire 
%	eval([Geometrie(i,:) '=' ...
%		Avion '.geom.' Geometrie(i,:) ';']);
% Cette solution est adapt�e lorsque les donn�es avion
% sont transmises par fichier brut de type %	Donn�esDC8;
% Dans ce cas le nom de l'avion "DC8" est transmis avec la structure
% Mais si les donn�es sont transmises par fonction du type
% [Avion] = DonneesDC8(parametres) ;
% Alors on peut programmer directement 
%	eval([Geometrie(i,:) '=' ...
%		 'Avion.geom.' Geometrie(i,:) ';']);
% Mais il faut respecter et garder le terme "Avion" entre
% l'appel de  [Avion] = DonneesDC8(parametres) ;
% et l'ex�cution de 
%	TransfertDonnees;


%_____________________________________________________________
Masse=...
['masse';'A    ';'B    ';'C    ';'ms   '];
%Masse(2,:) = 'A    '
% Attention : les noms de coefs 'Cnp  ' doivent tous 
% avoir la m�me dimension, ici 5 

%___ Transfert des donn�es Massiques ________
for i = 1:size(Masse,1) 
	eval([Masse(i,:) '=' ...
		'Avion.masse.' Masse(i,:) ';']);
end


CoefAeroLongi=...
['Cza   ';'Czmax ';'Czmax1';'Czmax2';'Czmax3';'Czmax4';...
'A0    ';'CzaE  ';'Cx0   ';'ki    ';'DCx0  ';'Cxdm  ';...
 'Cma   ';'Cm0   ';'Cmq   ';'Czdm  ';'Cmdm  '];
%CoefAeroLongi(2,:) = 'Cz   '
% Attention : les noms de coefs 'Cnp  ' doivent tous 
% avoir la m�me dimension, ici 6 

%___ Transfert des coefficients Longitudinaux ________
for i = 1:size(CoefAeroLongi,1) 
	eval([CoefAeroLongi(i,:) '=' ...
		'Avion.coef.' CoefAeroLongi(i,:) ';']);
end

CoefAeroLateral=...
['Cnb  ';'Cnr  ';'Cnp  ';'Clb  ';'Clr  ';'Clp  ';...
 'Cnb25';'Cyb  ';'Cydl ';'Cydn ';'Cndl ';'Cndn ';...
'Cldl ';'Cldn '];
%CoefAeroLateral(2,:) = 'Cnp'
% Attention : les noms de coefs 'Cnp  ' doivent tous 
% avoir la m�me dimension, ici 5 

%___ Transfert des coefficients Lat�raux ________
for i = 1:size(CoefAeroLateral,1) 
	eval([CoefAeroLateral(i,:) '=' ...
		'Avion.coef.' CoefAeroLateral(i,:) ';']);
end

%eval(['CnrT =' 'Avion.coef.Cnr;']);


Moteur=...
['Lf   ';'Fm0  '];
%Moteur(2,:) = 'Cz   '
% Attention : les noms de coefs 'Cnp  ' doivent tous 
% avoir la m�me dimension, ici 5 

%___ Transfert des donn�es Moteur ________
for i = 1:size(Moteur,1) 
	eval([Moteur(i,:) '=' ...
		'Avion.moteur.' Moteur(i,:) ';']);
end



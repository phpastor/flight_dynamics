
% Fichier AtmStand.m
%__________ Logiciels JLB Octobre 2001 _____________
% Programme modifi� de "SUPRERO" de Jan Raska
%
% mod�le de l'atmosph�re standard 
% sous forme de fonction
% [Atmo] = AtmStand(Altitude,Catm)
%
% Les entr�es sont les constantes des lois de 
% 	l'atmosph�re standard "Catm" 
% 	et l'altitude "Altitude" en m�tres
%
% Les constantes de l'atmosph�re standard,
% sous la structure "Catm" sont dans le fichier "CAtmStand"
% qui doit �tre appel� au moins 
% une fois avant de faire appel 
% � "AtmStand", le programme ci-dessous.

% En sortie, sous la structure "Atmo", on trouve 
% la pression, temp�rature, vitesse du son, 
% densit� de l'air, viscosit�s 
% Atmo.Pression = pression ;
% Atmo.Temperature = temperature ;
% Atmo.VitSon = sqrt(Catm.gammacpscv.*Catm.Rgazparfait.*temperature) ;
% Atmo.Densite = pression./Catm.Rgazparfait./temperature ;
% Atmo.VisDyn = Catm.VisDyn00.*temperature.^(1.5)./(temperature + Catm.TVisDyn);
% Atmo.VisCin = Atmo.VisDyn./Atmo.Densite;
%
% Cette fonction est utilis�e par "TableAtm.m" 
% pour produire les tables de 
% l'atmosph�re standard dans un tableau LaTeX
%______________________________________________________
%!!!!!! Temperature thermodynamique en K, Altitude m !!!!!!!


function [Atmo] = AtmStand(Altitude,Catm);

% Les constantes de l'atmosph�re standard,
% sous la structure "Catm" sont dans le fichier "CAtmStand"
% qui doit donc �tre lu une fois avant l'appel de la
% fonction "AtmStand"


%  Vecteurs logiques pour d�tecter les tranches d'altitudes 
% �gale � 1 si h < h1=11 km
LogA0011 = (Altitude < Catm.Altitude1) ; 
% �gale � 1 si h2=20 km > h > h1=11 km
LogA1120 = (Altitude >= Catm.Altitude1 & Altitude <= Catm.Altitude2) ;
% �gale � 1 si h > h2=20 km
LogA2032 = (Altitude > Catm.Altitude2) ; 

%_________ Calculs de T et p par tranche d'altitude
% les diff�rentes fonctions, par tranches, ne sont appliqu�es 
% aux �l�ments des vecteurs pression et temp�rature que si 
% la variable logique "LogA0011", "LogA1120" ou "LogA2032" est �gale � 1

%if Altitude < Catm.Altitude1

%       pour altitude H entre 0 et 11000m 
temperature(LogA0011) = Catm.Temperature0 ... 
	- Catm.kTemperature1.*Altitude(LogA0011);
pression(LogA0011) = Catm.pression0.*(1  ... 
	-Catm.kpression1.*Altitude(LogA0011)).^Catm.alfap1;          

%elseif Altitude < Catm.Altitude2
    
%       pour altitude H entre 11000 et 20000m
temperature(LogA1120) = Catm.Temperature2;
pression(LogA1120) = Catm.pression2.*exp(Catm.alfap2.*(Altitude(LogA1120)  ... 
	- Catm.Altitude1));

%else
    	
%       pour altitude H entre 20000 et 32000m
temperature(LogA2032) = Catm.Temperature2  ... 
	+ Catm.kTemperature3.*(Altitude(LogA2032) - Catm.Altitude2);
pression(LogA2032) = Catm.pression3.*(1+Catm.kpression3.*(Altitude(LogA2032) ... 
	 -Catm.Altitude2)).^Catm.alfap3; 

%end

%_________ Autres variables d�riv�es de p et T ______________
Atmo.Pression = pression ;
Atmo.Temperature = temperature ;
% Vitesse du son
Atmo.VitSon = sqrt(Catm.gammacpscv.*Catm.Rgazparfait.*temperature) ;
% Masse volumique rho
Atmo.Densite = pression./Catm.Rgazparfait./temperature ;
% Viscosit� (dynamique)
Atmo.VisDyn = Catm.VisDyn00.*temperature.^(1.5)./(temperature + Catm.TVisDyn);
% Viscosit� cin�matique)
Atmo.VisCin = Atmo.VisDyn./Atmo.Densite; 


 

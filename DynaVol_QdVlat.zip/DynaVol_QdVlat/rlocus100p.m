 function [rout]=rlocusp(a,b,c,d,kk,str)
%RLOCUSP Lieu des racines points par points .
%       Ne pr�sente un int�ret que dans le cas d'un syst�me
%       d�crit par sa repr�sentation d'�tat.
%       (sinon utiliser RLOCUS).
%       macro utiliser principalement par RSQLOCUS.
%
%       RLOCUSP(A,B,C,D) ou RLOCUSP(SYSIN) 
%       calcule et trace le lieu des valeurs
%       propres de la matrice:
%
%            Abf=A-kBC
%
%       pour un jeu de gains k calcule automatiquement (100 pts).
%
%       R=RLOCUSP(A,B,C,D,K) ou (SYSIN,K) permet de fixer dans le vecteur K
%       les variations du gain et retourne une matrice R avec 
%       LENGTH(K) colonnes et LENGTH(A) lignes contenant les 
%       valeurs propres pour les valeurs de gain correspondantes.
%
%       R=RLOCUSP(A,B,C,D,K,STR) OU (SYSIN,K,STR)
%       permet de fixer la caract�re et
%       la couleur (par exemple:STR='r.'; par d�faut STR='w+')) 
%       avec lequel sera trace le lieu.
%
%       Voir aussi RLOCUS, PZMAP

%#

%       D. Alazard 22-02-94      12/98
        
if nargin==0, eval('exresp(''rlocusp'');'), return, end
%if nargin==1, [a,b,c,d]=test_natss(a);end;
%if nargin==2, kk=b;[a,b,c,d]=test_natss(a);end;
%if nargin==3, str=c;kk=b;[a,b,c,d]=test_natss(a);end;
[m,n] = size(a);
[mb,nb] = size(b);
[mc,nc] = size(c);
if (nb ~= mc) 
        error('Le systeme doit etre carre. ');
end

ep=eig(a);
p=length(ep);
tz=tzero(a,b,c,d);
tz=tz(abs(tz)<1.e6);            % Ignore zeros greater than 1.e6
z=length(tz);
mep=max([eps;abs([real(ep);real(tz);imag(ep);imag(tz)])]);
        if z==p
                ax=1.2*mep;        
        else
                % Round graph axis    
                exponent=5*10^(floor(log10(mep))-1);
                ax=2*round(mep/exponent)*exponent;    
        end
holdon = ishold;
newplot;
if ~holdon
        plot([-ax,ax],[0,0],'w:',[0,0],[-ax,ax],'w:');
        axis([-ax,ax,-ax,ax])
else
        ax4 = axis;
        ax = sum(abs(ax4))/4;
        plot([ax4(1:2)],[0,0],'w:',[0,0],[ax4(3:4)],'w:');
        axis(ax4)
end
hold on
plot(real(ep),imag(ep),'x');
if ~isempty(tz)
        plot(real(tz),imag(tz),'o');
end
xlabel('Real Axis')
ylabel('Imag Axis')
erasemode = 'none';
drawnow
%
%Recherche des variations de gains
if (nargin==4)|(nargin==1)
        ii=0;
        k=eps;
        r(:,1)=ep;
        abf=a-b*((eye(size(d))+k*d)\(k*eye(size(d))))*c;
        [V,D]=eig(abf);
        sp=sum([1:length(a)].^2);
        while ii<=100,
                ii=ii+1;
                if cond(V)<100/eps,
                   U=inv(V);
                   dlamdai=[];
                   for jj=1:p
                        dlamdai=[dlamdai U(jj,:)*b*c*V(:,jj)];
                   end;
                   deltak=ax/100/max(abs(dlamdai));
                   k=k+deltak;
                   if isinf(k),k=1/eps;end;
                else,
                   k=k+1000*eps;
                end;
                abf=a-b*((eye(size(d))+k*d)\(k*eye(size(d))))*c;
                [V,D]=eig(abf);
                r(:,ii+1)=vsort(r(:,ii),diag(D),sp);
        end;
%
        for ii=1:length(a),
          plot(real(r(ii,:)),imag(r(ii,:)));
        end;
end;
if (nargin==5)|(nargin==2)
        for ii=1:length(kk)
                rout(:,ii)=eig(a-b*((eye(size(d))+kk(ii)*d)\...
                (kk(ii)*eye(size(d))))*c);
                plot(real(rout(:,ii)),imag(rout(:,ii)),'+');
        end
end
if (nargin==6)|(nargin==3)
        for ii=1:length(kk)
                rout(:,ii)=eig(a-b*((eye(size(d))+kk(ii)*d)\...
                (kk(ii)*eye(size(d))))*c);
                plot(real(rout(:,ii)),imag(rout(:,ii)),str);
        end
end
%
if ~holdon, hold off, end

%
%PROGRAMME : "CPhysique.m"

% constantes------------------------------------------------------------

gravite = 9.8067;          % gravite


    


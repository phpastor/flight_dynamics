function [VP] = MModes(Aetat)

% "MModes"   
% Ce programme calcule les modes d'un syst�me d'�tat (A, B, C, D)
%  Il faut lui fournir seulement A = Aetat et ses coefficients.
% Ces modes sont tri�s suivant leur distance � z�ro
% VP(i).valeur : les valeurs propres
% VP(i).mode : les modes en Constante de temps="tau", 
% P�riode="T" et amortissement r�duit "xi" 
% VP(i).texte : le texte des modes (utiles aux l�gendes)
% "i" : nombre de modes (un seul pour un mode oscillant)

%PROGRAMME : "MModes.m"

% A supprimer
%   vpcomplet=eig(Aetat);  % valeurs propres de Aetat
%s=size(Aetat);
%nAetat =s(1) ;



%_______ Vecteurs propres "Vec" et valeurs propres "Val" _______________
% "Vec" vecteur propre � droite (A Vec =  Vec Val)
% "Val" matrice diagonale des valeurs propres
	[Vec,Val] = eig(Aetat); 
% "Uec" vecteur propre � gauche Uec = Inverse(Vec) (Uec A = Val Uec)
%%	Uec = inv(Vec); % 

Val = diag(Val); % Vecteur colonne des valeurs propres

% nvp nombre de valeurs propres 
nvp =length(Val); % si nvp n'est pas �gal � nn et nx il y a une erreur


%_______ Tri et indices des valeurs propres _________
% K vecteur colonne des indices des p�les 
% la taille de K est �gale au nombre de p�les 
% i.e. que 2 valeurs propres complexes conjugu�es comptent pour un p�le
% par exemple "Val(K(:))" donne le vecteur des valeurs propres
% avec une seule valeur pour les modes complexes

	%_______ Recherche du nombre de p�les K _______
K  = [];  jj = 1;
while jj <= nvp;
	if imag(Val(jj)) == 0; % Modes r�els
		K  = [K;jj]; % Vecteur des indices des p�les
		jj = jj+1;
	else   %Modes complexes
		K  = [K;jj]; % Vecteur des indices des p�les
		jj = jj+2;
	end;
end;

[npol,mcv] = size(K); % npol nombre de p�le (1 p�le pour 2 VP imaginaires)
npolp = npol +1 ;


 	%______ Tri des modes
[Trash,IpermVal] = sort(abs(Val(K(:))));
	% sur la valeur absolue (distance � z�ro)
	% ValTri contient les valeurs propres tri�es par ordre croissant
	% et ne contient qu'une seule valeur propre
	% pour deux valeurs propres imaginaires conjugu�es
ValTri = Val(K(IpermVal(:)))  ;

%______ Valeurs et L�gendes des Valeurs Propres _______________________
fmt='%7.2f '; % format du texte de la l�gende des VP
for j = 1:npol
	%_____ Valeurs des Valeurs Propres ___________
	VP(j).valeur = ValTri(j) ;
	%_____ Textes et valeurs des l�gendes ________________
	% expression des valeurs propres en p�riode T, xi, et tau
	reelnum(j)=real(VP(j).valeur);
	imagnum(j)=imag(VP(j).valeur);

     if (imagnum(j) ~= 0)
		% abs(0) �a plante (Index into matrix is negative or zero) 
		% c'est pourquoi on ne prend pas le "abs" avant d'�tre 
		% sur un mode oscillant
		imagnum(j)= abs(imagnum(j)) ;
      	Periode(j) = 2*pi/imagnum(j) ;
		xlocal= (imagnum(j)/reelnum(j))^2;
		Amortreduit(j) = 1/sqrt(1+xlocal);
		% Mise en texte 
		VVPxi = sprintf(fmt,Amortreduit(j)); % amortissement r�duit
		VVPT = sprintf(fmt,Periode(j)); % P�riode (r�elle)
	VP(j).texte=['T=' VVPT 's' '  \xi = ' VVPxi];
	VP(j).mode= [Periode(j) Amortreduit(j)];
	else
  		Tau(j) = - 1/reelnum(j) ;
		VVPTau = sprintf(fmt,Tau(j)); % Constante de temps
	VP(j).texte=['\tau = ' VVPTau 's'];
	VP(j).mode= Tau(j) ;
         end
end


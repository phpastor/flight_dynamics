 %CALCUL DE TOUTES LES CONSTANTES DU PROBLEME
 
% Ce programme calcule le syst�me d'�tat (A, B, C, D)
%  et les valeurs propres

%PROGRAMME : "SystemeEtatLateral.m"



%____________ Coefficients interm�diaires ____________________

ap = lref*masse*gravite/Cz ; %alvmgsv
av = ap*lsv ; % al2mgsv

avA = av / A ; % al2mgsvACz
avC = av / C ; % al2mgsvCCz

apA = ap / A ; % alvmgsvACz
apC = ap / C ; % alvmgsvCCz

af=gsv/Cz; % g/(V*Cz)

% calcul des coefficients de la matrice----------------------------------

nr=avC*Cnr ;
np=avC*Cnp;
nb=apC*Cnb;
ndl=apC*Cndl;
ndn=apC*Cndn;

lr=avA*Clr;
lp=avA*Clp;
lb=apA*Clb;
ldl=apA*Cldl;
ldn=apA*Cldn;
  
ybsv=af*Cyb;
ydlsv=af*Cydl;
ydnsv=af*Cydn;



  %calcul de la matrice MAT et de ses valeurs propres---------------------

    Aetat=[ybsv -cos(Alpha) sin(Alpha) gsv*cos(Theta) ;...
	nb nr np 0;lb lr lp 0;0 tan(Theta) 1 0 ];
   Betat=[ydlsv ydnsv;ndl ndn;ldl ldn;0 0  ];
   Cetat=eye(4);
   Detat=zeros(4,2);


%________ Calcul des modes et impression _____________

%ModesLat ;
%WModesLat ;



%	Sauvegarde des Courbes trac�es par "TSimuTempModBE9.m"
% 
% Ce fichier sauvegarde la courbe trac�e par "TSimuTempModBE9.m"
% dans un fichier dont le nom est d�finit automatiquement
% sous un format .eps
%
%
%	PROGRAMME : "SCourbes.m"

%________________________________________________________
%________________________________________________________

cd :FiguresBELat:
print('-fgcf','-deps',[TFfigure]);
cd ::

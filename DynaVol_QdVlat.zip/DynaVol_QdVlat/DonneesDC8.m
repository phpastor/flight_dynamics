function [DC8]=DonneesDC8(ms,kCoef) ;
%Elaboration des donn�es d'un avion de type DC8
% en vue d'�tablir un mod�le d'�tat
%PROGRAMME : "DonneesDC8.m"
% Il y a un petit probl�me : au passage dans cette fonction
% la structure "DC8" s'affiche dans la feuille Matlab
% il manquerait un ";" quelque part mais o� ?

 DC8.nom = 'DC8' ;

%_____ Arguments par d�faut ___________
% Si aucun argument
if nargin==0, 
ms = 0.1 ;
kCoef = ones(1,3);
end
% Si un seul argument
% on suppose que c'est la marge statique ms
if nargin==1, kCoef = ones(1,3);end;


% Coefficients de correction de l'avion
kSD = kCoef(1); %Surface D�rive
kCnb= kCoef(2);%Cnb=CnBeta
kClb= kCoef(3);%Clb=ClBeta


   
%_____ Donn�es Avion _________________

%_____ G�om�trie _________________

DC8.geom.lref = 6.5;          % longueur de corde en m
DC8.geom.Sref = 240;          % Surface de reference en m2

%surface empennage horizontal en m2.
DC8.geom.SE = 0.25*DC8.geom.Sref ;
%surface d�rive nominale en m2.
 DC8.geom.SdN = 29.3 ;
%surface d�rive de calcul
 DC8.geom.Sd = kSD*DC8.geom.SdN ;

% Donn�es de l'A300 � mettre � jour pour le DC8
DC8.geom.b = 44.84 ;% Envergure de l'aile
DC8.geom.bE = 16.24 ;% Envergure de l'empennage horizontal
DC8.geom.d = 23 ;% Distance du Foyer � l'Empennage
DC8.geom.ym = 8 ;% Distance du moteur au fuselage
	% Allongements Aile et Empennage
DC8.geom.LA = DC8.geom.b^2/DC8.geom.Sref;
DC8.geom.LE = DC8.geom.bE^2/DC8.geom.SE;



%_____ Masses _________________

DC8.masse.masse = 120000;
DC8.masse.A = 5880000;
DC8.masse.B = 9720000;
DC8.masse.C = 11100000;
DC8.masse.E = -33000;

% Marge statique ms=(xF-xG)/l, centrage=xG/l
DC8.masse.ms = ms; % (xF-xG)/l
%DC8.masse.xFsL = 0.4 ; % xF/l % �valuation d'apr�s coefs
DC8.masse.xFsL = 0.6 ; % xF/l %au 10 d�c 02
%DC8.masse.xFsL = 0.5 ; % xF/l %au 10 d�c 02
DC8.masse.centrage=DC8.masse.xFsL-DC8.masse.ms;% xG/l

%______coefficients a�rodynamiques 


DC8.coef.Cx0 = 0.02;
DC8.coef.ki = 0.06 ;% Coef de tra�n�e induite
DC8.coef.DCx0 = 0.036;% spoiler en croisiere
DC8.coef.Cxdm = 0.0;
%			
% Coef de portance et incidence
DC8.coef.Cza = 5 ;% Cz alpha gradient de portance
%DC8.coef.Cza = 2*pi/(1+2/DC8.geom.LA);
DC8.coef.CzaE = 2*pi/(1+2/DC8.geom.LE);

DC8.coef.Czmax = 1.2 ; % Czmax lisse en croisi�re
DC8.coef.Czmax1 = 1.5 ; % Czmax conf 1 becs au d�collage
DC8.coef.Czmax2 = 1.2 ; % Czmax conf 2 becs, 17� volets au d�collage
DC8.coef.Czmax3 = 2.0 ; % Czmax conf 3 
DC8.coef.Czmax4 = 2.5 ; % Czmax conf 4 tout sorti � l'atterrissage

DC8.coef.A0 = - 2*pi/180 ; % Alpha z�ro en radian
DC8.coef.Cma = DC8.masse.ms*DC8.coef.Cza;   
DC8.coef.Cm0 = - 0.1 ;


%DC8.coef.Cmq = - (DC8.geom.SE/DC8.geom.Sref) ...
%	*(DC8.geom.d/DC8.geom.lref)^2*DC8.coef.CzaE;
DC8.coef.Cmq = - 15;


DC8.coef.Czdm =  0.44 ;
DC8.coef.Cmdm = - 1.46 ;


%..................coefficients a�rodynamiques lat�raux
%			donnes pour centrage=0.25

DC8.coef.Cnp = -1.37;      
% consid�r�s comme presque invariants avec le centrage
DC8.coef.Clr = 5.89;       
DC8.coef.Clp = -18.6;      
% et ind�pendants de la surface d�rive.

% Nov 2002, apr�s de nombreuses modifs, 
% Coef correcteur au Clb pour retrouver le mode spiral
% de novembre 2001 . A supprimer � terme !
		%kBE02=1.2;
		%DC8.coef.Clb = -0.92 * kBE02*kClb;
DC8.coef.Clb = -0.92 * kClb;
%% DC8.coef.Clb = -0.92 ;


DC8.coef.Cnb25 = (-0.56+0.0526*DC8.geom.Sd)*kCnb ;

	%_____coefficients variant avec la surface de la d�rive
	% 		et le centrage

DC8.coef.Cyb=-0.15-0.0171*DC8.geom.Sd;
% Formule 
DC8.coef.Cnb= DC8.coef.Cnb25 + (DC8.masse.centrage-0.25)*DC8.coef.Cyb;
DC8.coef.Cnr=(-2.45-0.162*DC8.geom.Sd);


	%_____coefficients de gouverne
DC8.coef.Cydl= 0 ;
DC8.coef.Cydn= 0.19 ;
DC8.coef.Cndl= -0.02 ;
DC8.coef.Cndn= -0.56 ;
DC8.coef.Cldl= -0.56 ;
DC8.coef.Cldn= 0.13 ;


%_____ Moteur _________________

DC8.moteur.Lf = 0.5; % exposant de la vitesse dans la pouss�e
DC8.moteur.Fm0 = 4*60e+3; % Pouss�e maximale au sol � V=0
% de l'ensemble des moteurs en Newton, ici 2 moteurs



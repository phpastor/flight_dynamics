
%======================================================
%  
%  Placement de modes par retour de sorties
%  sur une forme d'�tat.
%
%  Cas particulier :
%     * syst�me d'ordre 4 avec 4 sorties et deux entr�es
%     * placement d'une paire de modes complexes
%     * retour d'une entr�e avec deux sorties
%
%======================================================

%
%   Grandeurs � sp�cificier :
%

    %  Pulsation naturelle du mode en boucle ferm�e (rad/s)

   % omega = 1.57 ;
     omega = 1.17 ;
 
    %  Taux d'amortissement du mode en boucle ferm�e
 
    ksi  = 0.7 ;

    % Indice de l'entr�e du syst�me � utiliser
  
    %  Ient = 1  ; % dl
       Ient = 2  ; % dn

    % IndiceS des sorties prises en compte (il en faut deux)

       Isor =  1:2 ; % beta, r
     % Isor =  3:4 ; % p, phi

%------------------------------------
%
%  Calcul des valeurs propres en B.F.
%
%------------------------------------

  PolyCar = [1 2*ksi*omega omega^2] ;
  lambda = roots(PolyCar);

%----------------------------------------------------
%
%   Pour chaque p�le lambda_i, calcul du vecteur V_i
%   tel que
%
%       [A - lambda_i I    b] V_i = 0
%
%   o� b est la colonne de la matrice B de la
%   forme d'�tat correspondant � l'entr�e retenue 
%
%----------------------------------------------------

  b = Betat( : , Ient) ; 
  I = eye(4)       ; % Matrice identit� 4x4 

  V1 = null( [Aetat- lambda(1) * I ,  b]  );

  V2 = null( [Aetat- lambda(2) * I ,  b]  );
 
  u1 = V1(1:4) ;
  u2 = V2(1:4) ;

  w1 = V1(5)   ;
  w2 = V2(5)   ;

%-----------------------------------------------
%
%  Formation du gain de retour
%
%------------------------------------------------

 Klat = [w1 , w2] * inv( Cetat(Isor, :) * [u1 , u2] ) ;

 Klat = real(Klat) ; % mise � z�ros des r�sidus de calcul

%---------------------------------------
%
%  Formation de la matrice des gains 
%  pour le syst�me complet
%
%----------------------------------------

 KPlaceMod = zeros(2, 4) ;
 KPlaceMod(Ient, Isor) = Klat ;

 %  ATTENTION !!!
 %    Si cette matrice existe, elle sera prise en compte
 %    dans la simulation et le trac� des lieux des modes � la place
 %    des gains sp�cifi�s individuellement dans InitSimulation.m
 %
 %    Si vous souhaitez ne plus la prendre en compte, il faut l'effacer par  :
 %     clear KPlaceMod


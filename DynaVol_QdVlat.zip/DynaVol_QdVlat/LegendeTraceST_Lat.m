

%______ L�gendes Lat�rales en marge des figures ___________

strBeta  = {'D�rapage'    , '\beta '      , '(degr�)'   , '  ' } ; 
strRrrr  = {'Vitesse de ' , 'lacet r '    , '(degr�/s)' , '  ' } ;   
strPppp  = {'Vitesse de ' , 'roulis p '   , '(degr�/s)' , '  ' } ; 
strPhi   = {'Angle de '   , ' gite \phi ' , '(degr�)'   , '  ' } ; 

% L�gendes des �tats en vecteur

strLegFig(1,:,:) = strBeta(:,:); strLegFig(2,:,:) = strRrrr(:,:);
strLegFig(3,:,:) = strPppp(:,:); strLegFig(4,:,:) = strPhi(:,:);
%
Legendes.Fig = strLegFig ;

% L�gendes en "x" 

Legendes.X= {' Temps '} ;

%  Titre g�n�ral Simu Lat�rale 

strTitre = {['Simulation lat�rale - Cas de vol : V = ', num2str(VitVol), ...
              'm/s,  H = ' num2str(AltVol), ' m, m_s = ' , num2str(msVol)] } ; 

Legendes.Titre = strTitre ;

% Titre suppl�mentaire en bas de courbe 

Legendes.Simu= {' '}; 

%  L�gendes des modes en vecteur 

[trash,npol] = size(VP);

for ii=1:npol+1;% boucle sur les modes %
		if ii==1 
			A = ' simulation globale';
		else
			A = VP(ii-1).texte;
		end
	Legendes.Modes(ii)= cellstr(A);
end;

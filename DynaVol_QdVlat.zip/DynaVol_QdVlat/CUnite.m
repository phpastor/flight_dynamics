%****************************************************************
%  Fichier CUnite.m

% CONSTANTES pour la conversion des unit�s 
% facteurs de conversion 
%_____________________________________________
% EXEMPLES :
%
% de Livre (lb) en Newton (N) lbf => N : factlbf2N 
% valable pour les lbf, lbs (force et lb au pluriel ) 
% attention c'est diff�rent pour les lbm (masse)
% exemple : m_lb * factlbf2N = m_N
% de Livre (lb) en kilogramme (kg) lbm => kg : factlbm2kg 

% De pied (ft) en m�tre (m) ft => m : factft2m
% De m�tre (m)  en pied (ft) m => ft : factm2ft

% De HorsePower (HP) en kiloWatt (kW) hp => kW: facthp2kW
% De HorsePower (HP) en Watt (W) hp => kW: facthp2W

% Consommation sp�cifique de lbm / (lbf .h ) en SI 
% cad kg / (N.s) : factCslbh2SI


%_______ Conversion radian en degr�s (rad -> degre)
rad2deg = 180/pi ;
% conversion  degr�s en radian (degre -> rad)
deg2rad = 1/rad2deg ;

%_________ Masses, Forces, Puissances
% facteurs de Conversion 
% lbf => N
factlbf2N = 4.4482 ;
% lbm => kg
factlbm2kg = 0.453592  ;
% ft => m
factft2m = 0.3048 ;
% m => ft : 
factm2ft = 3.28084 ;
% inch '' => m
factinch2m = 0.02540 ;
%  hp => kW
facthp2kW = 0.74572 ;
%  hp => W
facthp2W = 745.72 ;

%_________ Consommations sp�cifiques 

% Cs lbm / (lbf .h ) en SI cad kg / (N.s) 
factCslbh2SI = 0.453592 / (4.4482 * 3600 ) ;
% Cs SI cad kg / (N.s) en lbm / (lbf .h )
factCsSI2lbh = 1 / factCslbh2SI ;
% Cs SI cad kg / (N.s) en pseudoSI cad kg / (daN.h )
% faux le 16 d�c 98 (de N en daN c'est 10 et pas 9.81)
%factCsSI2kgdaNh = 9.80665 * 3600  ; 
factCsSI2kgdaNh = 10 * 3600  ;




